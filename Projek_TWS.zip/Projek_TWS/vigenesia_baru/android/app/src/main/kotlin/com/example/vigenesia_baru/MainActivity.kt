package com.example.vigenesia_baru

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
