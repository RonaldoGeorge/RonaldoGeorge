import 'package:flutter/material.dart';
import 'package:vigenesia_baru/Screens/Login.dart';

void main() => runApp(MaterialApp(
  debugShowCheckedModeBanner: false,
  home: Login(),
));